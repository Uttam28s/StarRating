import Index from "./Component/Index";
import "./Scss/App.scss";

function App() {
  return <Index />;
}

export default App;
